# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ghp']

package_data = \
{'': ['*']}

install_requires = \
['blessed>=1.17.12,<2.0.0',
 'click>=7.1.2,<8.0.0',
 'ipython>=7.19.0,<8.0.0',
 'more_itertools>=8.6.0,<9.0.0',
 'tabulate>=0.8.7,<0.9.0']

entry_points = \
{'console_scripts': ['status = ghp.cli:run']}

setup_kwargs = {
    'name': 'ghp',
    'version': '0.1.0',
    'description': 'CLI utility for querying the Github API for status of Pages/Actions',
    'long_description': None,
    'author': 'Alissa Huskey',
    'author_email': 'alissa.huskey@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/alissa-huskey/gh-pages-cli',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
